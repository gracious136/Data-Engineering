import sqlalchemy as db # import the library
import json
import pandas as pd
import requests
import os

def lambda_handler(event, context):
  #using trom my city_info_data table
    open_weather_key = os.environ['open_weather_key']
    schema="city_projects"
    host="wbs-data-engineering-db.c15vc1c2zias.eu-central-1.rds.amazonaws.com"
    user="admin"
    password= os.environ['aws_db_password']
    port=3306
    aws_connection_string = f'mysql+pymysql://{user}:{password}@{host}:{port}/{schema}'
    aws_sql_engine = db.create_engine(aws_connection_string, echo=True) 
    aws_connection = aws_sql_engine.connect()
    query = db.text("SELECT * FROM city_info_data")
    df = pd.read_sql(query, aws_connection)
    
    city_result = []
       
    for _, row in df.iterrows():
        lat = row['latitude']
        lon = row['longitude']
        city = row['city']
        city_id = row['city_id']

        url = f'http://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={open_weather_key}&units=metric'
        response = requests.get(url)
        result = response.json()

        for i in range(len(result['list'])):
          output = {  'city_id' :city_id,
                      'min_temperature' : result['list'][i]['main']['temp_min'],
                      'max_temperature' : result['list'][i]['main']['temp_max'],
                      'temperature' : result['list'][i]['main']['temp'],
                      'real_feel' : result['list'][i]['main']['feels_like'],
                      'date' : result['list'][i]['dt_txt'],
                      'outlook' : result['list'][i]['weather'][0]['main'],
                      'description' : result['list'][i]['weather'][0]['description'],
                      'rain_volume' : result['list'][i].get((result['list'][i]['weather'][0]['main']).lower(), {}).get('3h', 0),
                      'humidity' : result['list'][i]['main']['humidity'],
                      'wind_speed' : result['list'][i]['wind']['speed'],
                      'part_of_day' : (lambda x: 'day' if x =='d' else 'night')(result['list'][i]['sys']['pod'])
                     }
          city_result.append(output)

    weather_data = pd.DataFrame(city_result)  
    weather_data['date'] = pd.to_datetime(weather_data['date'])
    #empty_df = pd.DataFrame(columns=weather_data.columns)
   # empty_df.to_sql('city_weather_data', aws_connection, if_exists='append', index=False)
    weather_data.to_sql('city_weather_data', aws_connection, if_exists='append', index=False)
    aws_connection.commit()
    aws_connection.close()

    return response.status_code




