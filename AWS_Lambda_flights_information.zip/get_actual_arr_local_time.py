def main(response, i):
    if 'arrivals' in response and len(response['arrivals']) > i and 'movement' in response['arrivals'][i] and 'actualTimeLocal' in response['arrivals'][i]['movement']:
        return response['arrivals'][i]['movement']['actualTimeLocal'].split(' ')[1].split('+')[0]
    else:
        return response['arrivals'][i]['movement']['scheduledTimeLocal'].split(' ')[1].split('+')[0]