import os
import pandas as pd
import sqlalchemy as db
import json
import requests 
from datetime import datetime, timedelta
import get_arrival_date
import get_actual_arr_local_time
import get_delay_time

def main(event, context):
    flight_api_key = os.environ['api_key']
    schema="city_projects"
    host="wbs-data-engineering-db.c15vc1c2zias.eu-central-1.rds.amazonaws.com"
    user="admin"
    password= os.environ['aws_db_password']
    port=3306
    aws_connection_string = f'mysql+pymysql://{user}:{password}@{host}:{port}/{schema}'
    aws_sql_engine = db.create_engine(aws_connection_string, echo=True) 
    aws_connection = aws_sql_engine.connect()
    query = db.text("SELECT * FROM city_airports_data")
    df = pd.read_sql(query, aws_connection)
    

    flights_data = []
    times = [['00:00', '11:59'], ['12:00', '23:59']]

    for _, row in df.iterrows():

        icao = row['airport_icao']
        iata = row['airport_iata']
        airport_id = row['airport_id']
        tommorow_date = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
        
        for time in times:

            url = f"https://aerodatabox.p.rapidapi.com/flights/airports/icao/{icao}/{tommorow_date}T{str(time[0])}/{tommorow_date}T{str(time[1])}"
    
            querystring = {"withLeg":"false","direction":"Arrival","withCancelled":"true","withCodeshared":"true","withCargo":"false","withPrivate":"true","withLocation":"false"}
    
            headers = {
                "X-RapidAPI-Key": flight_api_key,
                "X-RapidAPI-Host": "aerodatabox.p.rapidapi.com"
            }
    
            responses = requests.get(url, headers=headers, params=querystring)
            
            
            
            if responses.status_code != 200: 
                print(f"Error - Status Code: {responses.status_code} at line{_}")
                print(f"Response Content: {responses.text}")
                print('Problem with status code')
                continue
                
            response = responses.json()
            
    
            for i in range(len(response['arrivals'])):
    
                output = {
                    'airport_id': airport_id,
                    'arrival_date' : get_arrival_date.main(response,i),
                    'flight_number' : response['arrivals'][i]['number'],
                    'airline' : response['arrivals'][i]['airline']['name'],
                    'flight_status' : response['arrivals'][i]['status'],
                    'scheduled_arr_local_time' : response['arrivals'][i]['movement']['scheduledTimeLocal'].split(' ')[1].split('+')[0],
                    'actual_arr_local_time' : get_actual_arr_local_time.main(response, i),
                    'scheduled_arr_UTC_time' : str(pd.to_datetime(response['arrivals'][i]['movement']['scheduledTimeUtc'])).split(' ')[1].split('+')[0],
                    'delay_time' : get_delay_time.main(response, i)
                    
                }
    
                flights_data.append(output)

    flights_df = pd.DataFrame(flights_data)
    flights_df['scheduled_arr_local_time'] = pd.to_datetime(flights_df['scheduled_arr_local_time']).dt.time
    flights_df['actual_arr_local_time'] = pd.to_datetime(flights_df['actual_arr_local_time']).dt.time
    flights_df['delay_time'] = flights_df['delay_time'].apply(lambda x: datetime.strptime(x, "%M:%S").strftime("%H:%M:%S"))
    #flights_df['flight_id'] = [num + 1000 for num in range(1, len(flights_df)+1)]
   
    
    empty_df = pd.DataFrame(columns=flights_df.columns)

    # Append the empty DataFrame to the SQL database.
    # This will update the table schema and allow the auto-increment mechanism to continue.
    empty_df.to_sql('city_flights_data', aws_connection, if_exists='append', index=False)
    flights_df.to_sql('city_flights_data', aws_connection, if_exists='append', index=False)
    aws_connection.commit()
    aws_connection.close()

    return responses.status_code

